import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

/**
 * Blood Bank Management System
 * S3 KTU OOPs Mini Project
 */
public class BloodBankSystem extends JFrame {

    private static final String DB_URL = "jdbc:sqlite:bloodbank.db";
    private static final String[] GROUPS = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};

    private JPanel cardPanel;
    private CardLayout cardLayout;

    public BloodBankSystem() {
        setTitle("Blood Bank Management System");
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initDatabase();

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        showHome();
        add(cardPanel);
    }

    private Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
           System.err.println("SQLite JDBC driver not found: " + e.getMessage());
        }
        return DriverManager.getConnection(DB_URL);
    }

    private void saveDonorAndUpdateStock(String name, int age, String phone, String bloodGroup, String lastDonation, String status) {
        String insertDonorSql = "INSERT INTO donors (name, age, phone, blood_group, last_donation, status) VALUES (?, ?, ?, ?, ?, ?)";
        String updateStockSql = "UPDATE stock SET units = units + 1 WHERE blood_group = ?";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement donorStmt = conn.prepareStatement(insertDonorSql);
                 PreparedStatement stockStmt = conn.prepareStatement(updateStockSql)) {

                donorStmt.setString(1, name);
                donorStmt.setInt(2, age);
                donorStmt.setString(3, phone);
                donorStmt.setString(4, bloodGroup);
                donorStmt.setString(5, lastDonation);
                donorStmt.setString(6, status);
                donorStmt.executeUpdate();

                // Only increment inventory if donor is currently available to donate
                if ("Available".equalsIgnoreCase(status)) {
                    stockStmt.setString(1, bloodGroup);
                    stockStmt.executeUpdate();
                }

                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean processBloodRequest(String recipientName, String bloodGroup, int unitsNeeded, String hospital, String location) {
        String checkStockSql = "SELECT units FROM stock WHERE blood_group = ?";
        String insertRequestSql = "INSERT INTO requests (name, blood_group, units, hospital, location, status) VALUES (?, ?, ?, ?, ?, 'Approved')";
        String updateStockSql = "UPDATE stock SET units = units - ? WHERE blood_group = ?";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false); // Begin transaction

            // 1. Check if sufficient stock is available
            int currentUnits = 0;
            try (PreparedStatement checkStmt = conn.prepareStatement(checkStockSql)) {
                checkStmt.setString(1, bloodGroup);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    currentUnits = rs.getInt("units");
                }
            }

            if (currentUnits < unitsNeeded) {
                JOptionPane.showMessageDialog(this, 
                    "Insufficient Stock! Available: " + currentUnits + " units, Requested: " + unitsNeeded, 
                    "Request Failed", JOptionPane.ERROR_MESSAGE);
                conn.rollback();
                return false;
            }

            // 2. Insert request record & 3. Deduct units from stock
            try (PreparedStatement reqStmt = conn.prepareStatement(insertRequestSql);
                 PreparedStatement stockStmt = conn.prepareStatement(updateStockSql)) {

                reqStmt.setString(1, recipientName);
                reqStmt.setString(2, bloodGroup);
                reqStmt.setInt(3, unitsNeeded);
                reqStmt.setString(4, hospital);
                reqStmt.setString(5, location);
                reqStmt.executeUpdate();

                stockStmt.setInt(1, unitsNeeded);
                stockStmt.setString(2, bloodGroup);
                stockStmt.executeUpdate();

                conn.commit(); // Save transaction
                return true;
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void initDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS donors (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, age INTEGER, phone TEXT, blood_group TEXT, " +
                    "last_donation TEXT, status TEXT)");

            stmt.execute("CREATE TABLE IF NOT EXISTS requests (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, blood_group TEXT, units INTEGER, " +
                    "hospital TEXT, location TEXT, status TEXT)");

            stmt.execute("CREATE TABLE IF NOT EXISTS stock (" +
                    "blood_group TEXT PRIMARY KEY, units INTEGER)");

            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM stock");
            if (rs.next() && rs.getInt(1) == 0) {
                try (PreparedStatement pstmt = conn.prepareStatement("INSERT INTO stock VALUES(?, ?)")) {
                    for (String bg : GROUPS) {
                        pstmt.setString(1, bg);
                        pstmt.setInt(2, 10);
                        pstmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Initialization Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setForm(String title, JPanel contentPanel) {
        JPanel wrapper = new JPanel(new BorderLayout());

        JLabel header = new JLabel(title, SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 20));
        header.setOpaque(true);
        header.setBackground(new Color(178, 34, 34));
        header.setForeground(Color.WHITE);
        header.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

        wrapper.add(header, BorderLayout.NORTH);
        wrapper.add(contentPanel, BorderLayout.CENTER);

        cardPanel.add(wrapper, title);
        cardLayout.show(cardPanel, title);
    }

    private JButton button(String text, java.awt.event.ActionListener listener) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBackground(new Color(220, 220, 220));
        btn.addActionListener(listener);
        return btn;
    }

    private JButton back() {
        return button("Back to Home", e -> showHome());
    }

    private void showHome() {
        JPanel home = new JPanel(new GridLayout(2, 3, 20, 20));
        home.setBackground(Color.WHITE);
        home.setBorder(BorderFactory.createEmptyBorder(60, 60, 60, 60));

        home.add(button("Become a Donor", e -> registerDonorForm()));
        home.add(button("Find Donor", e -> findDonorForm()));
        home.add(button("Request Blood", e -> bloodRequestForm()));
        home.add(button("Blood Availability", e -> showAvailability()));
        home.add(button("Admin Dashboard", e -> adminLoginForm()));

        setForm("Welcome to Blood Bank System", home);
    }

    private void registerDonorForm() {
        JPanel p = new JPanel(new GridLayout(6, 2, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(30, 80, 30, 80));

        JTextField name = new JTextField(), age = new JTextField(), phone = new JTextField(), lastDonation = new JTextField();
        JComboBox<String> group = new JComboBox<>(GROUPS);

        p.add(new JLabel("Full Name:")); p.add(name);
        p.add(new JLabel("Age (18-65):")); p.add(age);
        p.add(new JLabel("Phone Number:")); p.add(phone);
        p.add(new JLabel("Blood Group:")); p.add(group);
        p.add(new JLabel("Last Donation Date (YYYY-MM-DD, optional):")); p.add(lastDonation);

        p.add(button("Register", e -> {
            String nameTxt = name.getText().trim(), ageTxt = age.getText().trim(), phoneTxt = phone.getText().trim();
            String lastDonTxt = lastDonation.getText().trim();

            if (nameTxt.isEmpty() || ageTxt.isEmpty() || phoneTxt.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
                return;
            }

            try {
                int parsedAge = Integer.parseInt(ageTxt);
                if (parsedAge < 18 || parsedAge > 65) {
                    JOptionPane.showMessageDialog(this, "Age must be between 18 and 65 to register as a donor.");
                    return;
                }

                String status = "Available";
                if (!lastDonTxt.isEmpty()) {
                    try {
                        LocalDate lastDate = LocalDate.parse(lastDonTxt);
                        if (lastDate.isAfter(LocalDate.now())) {
                            JOptionPane.showMessageDialog(this, "Last donation date cannot be in the future.");
                            return;
                        }
                        long daysBetween = ChronoUnit.DAYS.between(lastDate, LocalDate.now());
                        if (daysBetween < 90) {
                            status = "Unavailable";
                        }
                    } catch (DateTimeParseException ex) {
                        JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.");
                        return;
                    }
                }

                String formattedLastDonation = lastDonTxt.isEmpty() ? "None" : lastDonTxt;
                String selectedGroup = group.getSelectedItem().toString();

                saveDonorAndUpdateStock(nameTxt, parsedAge, phoneTxt, selectedGroup, formattedLastDonation, status);

                JOptionPane.showMessageDialog(this, "Registration Successful!\nDonor Status: " + status + 
                    ("Available".equals(status) ? "\nStock Updated (+1 Unit)" : ""));
                showHome();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Age must be a valid number.");
            }
        }));

        p.add(back());
        setForm("Donor Registration", p);
    }

    private void findDonorForm() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER));
        top.setOpaque(false);
        JComboBox<String> groupSelect = new JComboBox<>(GROUPS);
        top.add(new JLabel("Select Blood Group Needed:"));
        top.add(groupSelect);

        String[] cols = {"ID", "Name", "Age", "Phone", "Blood Group", "Last Donation", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        table.setRowHeight(22);

        JButton searchBtn = button("Search", e -> {
            model.setRowCount(0);
            String selectedGroup = groupSelect.getSelectedItem().toString();
            String sql = "SELECT * FROM donors WHERE blood_group = ? AND status = 'Available'";

            try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, selectedGroup);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getInt("id"), rs.getString("name"), rs.getInt("age"),
                            rs.getString("phone"), rs.getString("blood_group"),
                            rs.getString("last_donation"), rs.getString("status")
                    });
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Search Error: " + ex.getMessage());
            }
        });

        top.add(searchBtn);
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bot = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bot.setOpaque(false);
        bot.add(back());
        p.add(bot, BorderLayout.SOUTH);

        setForm("Search Available Donors", p);
    }

    private void bloodRequestForm() {
        JPanel p = new JPanel(new GridLayout(6, 2, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(30, 80, 30, 80));

        JTextField name = new JTextField(), units = new JTextField(), hospital = new JTextField(), loc = new JTextField();
        JComboBox<String> group = new JComboBox<>(GROUPS);

        p.add(new JLabel("Patient / Recipient Name:")); p.add(name);
        p.add(new JLabel("Blood Group Required:")); p.add(group);
        p.add(new JLabel("Units Required:")); p.add(units);
        p.add(new JLabel("Hospital:")); p.add(hospital);
        p.add(new JLabel("Location:")); p.add(loc);

        p.add(button("Submit Request", e -> {
            String nameTxt = name.getText().trim(), unitsTxt = units.getText().trim();
            String recipientGroup = group.getSelectedItem().toString();
            String hospTxt = hospital.getText().trim();
            String locTxt = loc.getText().trim();

            if (nameTxt.isEmpty() || unitsTxt.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter Patient Name and Units Required.");
                return;
            }

            try {
                int unitsNeeded = Integer.parseInt(unitsTxt);
                if (unitsNeeded <= 0) {
                    JOptionPane.showMessageDialog(this, "Units required must be greater than 0.");
                    return;
                }

                if (processBloodRequest(nameTxt, recipientGroup, unitsNeeded, hospTxt, locTxt)) {
                    JOptionPane.showMessageDialog(this,
                            "SUCCESS! Blood request automatically APPROVED.\n" +
                                    unitsNeeded + " unit(s) allocated from inventory.",
                            "Request Approved", JOptionPane.INFORMATION_MESSAGE);
                    showHome();
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Units must be a valid number.");
            }
        }));

        p.add(back());
        setForm("Request Blood", p);
    }

    private void showAvailability() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] cols = {"Blood Group", "Available Units"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        table.setRowHeight(25);

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM stock")) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("blood_group"), rs.getInt("units")});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching stock: " + ex.getMessage());
        }

        p.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bot = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bot.setOpaque(false);
        bot.add(back());
        p.add(bot, BorderLayout.SOUTH);

        setForm("Current Blood Availability", p);
    }

    private void adminLoginForm() {
        JPanel p = new JPanel(new GridLayout(3, 2, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(100, 150, 100, 150));

        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();

        p.add(new JLabel("Admin Username:")); p.add(user);
        p.add(new JLabel("Password:")); p.add(pass);

        p.add(button("Login", e -> {
            if (user.getText().equals("admin") && new String(pass.getPassword()).equals("admin123")) {
                showAdminMenu();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Credentials", "Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }));

        p.add(back());
        setForm("Admin Login", p);
    }

    private void showAdminMenu() {
        JPanel menu = new JPanel(new GridLayout(2, 2, 20, 20));
        menu.setBackground(Color.WHITE);
        menu.setBorder(BorderFactory.createEmptyBorder(60, 60, 60, 60));

        menu.add(button("View Registered Donors", e -> viewDonors()));
        menu.add(button("Request Summary Report", e -> showRequestSummary()));
        menu.add(button("Add Blood Stock", e -> addStockForm()));
        menu.add(button("Logout", e -> showHome()));

        setForm("Admin Dashboard", menu);
    }

    private void viewDonors() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] cols = {"ID", "Name", "Age", "Phone", "Blood Group", "Last Donation", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        JTable table = new JTable(model);
        table.setRowHeight(22);

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM donors")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"), rs.getString("name"), rs.getInt("age"),
                        rs.getString("phone"), rs.getString("blood_group"),
                        rs.getString("last_donation"), rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching donors: " + ex.getMessage());
        }

        p.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bot = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bot.setOpaque(false);
        bot.add(button("Back to Dashboard", e -> showAdminMenu()));
        p.add(bot, BorderLayout.SOUTH);

        setForm("All Registered Donors", p);
    }

    private void showRequestSummary() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 15, 0));
        statsPanel.setOpaque(false);

        int totalRequests = 0;
        int approvedCount = 0;
        int rejectedCount = 0;
        int totalUnitsFulfilled = 0;

        String[] columnNames = {"ID", "Patient Name", "Group", "Units", "Hospital", "Location", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM requests ORDER BY id DESC")) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String group = rs.getString("blood_group");
                int units = rs.getInt("units");
                String hospital = rs.getString("hospital");
                String loc = rs.getString("location");
                String status = rs.getString("status");

                totalRequests++;
                if (status.startsWith("Approved")) {
                    approvedCount++;
                    totalUnitsFulfilled += units;
                } else {
                    rejectedCount++;
                }

                tableModel.addRow(new Object[]{id, name, group, units, hospital, loc, status});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error generating report: " + ex.getMessage());
            return;
        }

        statsPanel.add(createMetricCard("Total Requests", String.valueOf(totalRequests), new Color(70, 130, 180)));
        statsPanel.add(createMetricCard("Auto-Approved", String.valueOf(approvedCount), new Color(46, 139, 87)));
        statsPanel.add(createMetricCard("Auto-Rejected", String.valueOf(rejectedCount), new Color(178, 34, 34)));
        statsPanel.add(createMetricCard("Units Distributed", String.valueOf(totalUnitsFulfilled), new Color(128, 0, 128)));

        panel.add(statsPanel, BorderLayout.NORTH);

        JTable table = new JTable(tableModel);
        table.setRowHeight(25);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setOpaque(false);
        bottomPanel.add(button("Back to Dashboard", e -> showAdminMenu()));
        panel.add(bottomPanel, BorderLayout.SOUTH);

        setForm("Automated Request Summary Report", panel);
    }

    private JPanel createMetricCard(String title, String value, Color headerColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        card.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setOpaque(true);
        titleLabel.setBackground(headerColor);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel valueLabel = new JLabel(value, SwingConstants.CENTER);
        valueLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        valueLabel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private void addStockForm() {
        JPanel p = new JPanel(new GridLayout(3, 2, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(80, 120, 80, 120));

        JComboBox<String> group = new JComboBox<>(GROUPS);
        JTextField units = new JTextField();

        p.add(new JLabel("Blood Group:")); p.add(group);
        p.add(new JLabel("Units to Add:")); p.add(units);

        p.add(button("Update Stock", e -> {
            try {
                int addUnits = Integer.parseInt(units.getText().trim());
                if (addUnits <= 0) {
                    JOptionPane.showMessageDialog(this, "Units must be greater than 0.");
                    return;
                }

                String sql = "UPDATE stock SET units = units + ? WHERE blood_group = ?";
                try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, addUnits);
                    pstmt.setString(2, group.getSelectedItem().toString());
                    pstmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Stock updated successfully!");
                    showAdminMenu();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Units must be a valid number.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
            }
        }));

        p.add(button("Back to Dashboard", e -> showAdminMenu()));
        setForm("Add Physical Blood Stock", p);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BloodBankSystem app = new BloodBankSystem();
            app.setVisible(true);
        });
    }
}